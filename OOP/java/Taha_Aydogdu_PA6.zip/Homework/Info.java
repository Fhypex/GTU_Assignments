public interface Info {
    void info();
}