public interface Observer{
    // common methods 
    void update(Media media);
    void remove(Media media);
}