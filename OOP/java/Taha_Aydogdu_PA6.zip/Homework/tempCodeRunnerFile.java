class Homework{

    public static void main(String[] Args){
        System.out.println("Hello World");
    }


}